﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace BE
{

public enum Gender { male, female }  
public enum Campus { Lev, Tal}
public enum Semester {a,b,c }
}
